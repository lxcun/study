clc
clear all;
close all;
load('CNN_Training_noise7_20_5_data.mat');
label=zeros(100,1);
Trainlabels=zeros(100,7);
% for i=1:140000
%     x=Train_x_sig(:,:,:,i);
%     y=[x(1,:) x(2,:)];
%     trainData(i,:)=y(:);
%     label(i)=Train_y_sig(i);
% %     save('TrainData'+string(int2str(i-1))+'.txt','x','-ASCII');
% end
for i=1:100
    a(i,:)="|labels";
    b(i,:)="|features";
    label(i)=Train_y_sig(i);
    if label(i)==1
        Trainlabels(i,:)=[1 0 0 0 0 0 0];
    end
    if label(i)==2
        Trainlabels(i,:)=[0 1 0 0 0 0 0];
    end
    if label(i)==3      
        Trainlabels(i,:)=[0 0 1 0 0 0 0];
    end
    if label(i)==4  
        Trainlabels(i,:)=[0 0 0 1 0 0 0];
    end
    if label(i)==5   
        Trainlabels(i,:)=[0 0 0 0 1 0 0];
    end
    if label(i)==6
        Trainlabels(i,:)=[0 0 0 0 0 1 0];
    end
    if label(i)==7
        Trainlabels(i,:)=[0 0 0 0 0 0 1];
    end
   x=Train_x_sig(:,:,:,i);
   x1=x(1,:);
   x2=x(2,:);
   l=a(i,:);
   f=b(i,:);
   t=Trainlabels(i,:);
   y=[l t f x1 x2];
   z(i,:)=y;
end
%save('TestData_7_1_0z.mat','z');
[m,n]=size(z);
fid=fopen('TrainData7_20_5_1k.txt','a+');
for i=1:1:m
    for j=1:1:n
      if(j==n)
       fprintf(fid,'%s\n',z(i,j)); 
     else
        fprintf(fid,'%s\t',z(i,j));  
      end
    end
end
fclose(fid);


close all;
clear;
fs=20e6;
sigLength=256;%��������
sps=4;
qamvec=[64,16,8,4,2];
numOftrainData=1000;%�����ļ����źŸ���
numOfFiles=7;
for eee=1:numOfFiles
    X_file = sprintf('index of %d file is generating.',eee);
disp(X_file);
Train_y_sig=zeros(numOftrainData*length(qamvec),1);
Train_x_sig=zeros(2,sigLength/2*sps,1,numOftrainData*length(qamvec));
for j=1:length(qamvec)
    modtype=qamvec(j);
    addIndex=(j-1)*numOftrainData;
    parfor i=1:numOftrainData
        freqOff=randi([-1e6,1e6]);
        Poff=randi([-180,180]);
        pfo = comm.PhaseFrequencyOffset(...
            'FrequencyOffset',freqOff,...
            'PhaseOffset',Poff,...
            'SampleRate',fs);
        data = randi([0 modtype-1],sigLength,1);
        if modtype<16
            modSig = pskmod(data,modtype);
        else
            if modtype<129
            modSig = qammod(data,modtype,'UnitAveragePower',true);
            else
                if modtype==129
                    modSig=ammod(data,10,100);
                end
            end
        end
        alpha=rand(1)*0.5+0.05;
        txfilter = comm.RaisedCosineTransmitFilter( ...
            'OutputSamplesPerSymbol',sps,'RolloffFactor',alpha,...
            'FilterSpanInSymbols',10);
        pnoise = comm.PhaseNoise('Level',-90,'FrequencyOffset',300,'SampleRate',fs);
        modSigtx = txfilter(modSig);
        modSigOffset = pfo(modSigtx);
        SNR=randi([54,55]);
        outSig=awgn(modSigOffset,SNR,'measured');
        startindex=randi([20,sigLength*sps/2-1]);
        outSig=outSig(startindex:startindex+sigLength*sps/2-1);
        X_sig=zeros(2,length(outSig));
        for k=1:length(outSig)
           X_sig(1,k)= real(outSig(k));
           X_sig(2,k)= imag(outSig(k));
        end
        Train_x_sig(:,:,:,i+addIndex)=X_sig;
        Train_y_sig(i+addIndex) =j;
    end
end
Train_y_sig=categorical(Train_y_sig);
save ('CNN_Testing_5_data'+string(int2str(eee)), 'Train_x_sig','Train_y_sig');
end
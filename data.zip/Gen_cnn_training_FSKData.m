clc;
clear all;
close all;
fs=20e6;
sigLength=256;%��������
sps=4;
fskvec=[4,2];
numOftrainData=1000;%�����ļ����źŸ���
numOfFiles=30;
for eee=1:numOfFiles
     load('CNN_Training_data'+string(int2str(eee)), 'Train_x_sig','Train_y_sig');
    X_file = sprintf('index of %d file is generating.',eee);
disp(X_file);
% Train_y_sig=zeros(numOftrainData*length(fskvec),1);
% Train_x_sig=zeros(2,sigLength/2*sps,1,numOftrainData*length(fskvec));
for j=1:length(fskvec)
    modtype=fskvec(j);
    addIndex=(j-1)*numOftrainData+5*numOftrainData;
    parfor i=1:numOftrainData
        freqOff=randi([-1e6,1e6]);
        Poff=randi([-180,180]);
        pfo = comm.PhaseFrequencyOffset(...
            'FrequencyOffset',freqOff,...
            'PhaseOffset',Poff,...
            'SampleRate',fs);
        data = randi([0 modtype-1],sigLength,1);
        if modtype>8
            modSig = qammod(data,modtype,'UnitAveragePower',true);
        else
            modSig = fskmod(data,modtype,fs/4,sps,fs);
        end
        alpha=rand(1)*0.5+0.05;
        txfilter = comm.RaisedCosineTransmitFilter( ...
            'OutputSamplesPerSymbol',1,'RolloffFactor',alpha,...
            'FilterSpanInSymbols',10);
        pnoise = comm.PhaseNoise('Level',-90,'FrequencyOffset',300,'SampleRate',fs);
        modSigtx = txfilter(modSig);
        modSigOffset = pfo(modSigtx);
        SNR=randi([54,55]);
        outSig=awgn(modSigOffset,SNR,'measured');
        resampleRate=1+rand(1)*2;
        [q,p]=rat(resampleRate,1e-3);
        outSig=resample(outSig,q,p);
        startindex=randi([20,sigLength*sps/2-1]);
        outSig=outSig(startindex:startindex+sigLength*sps/2-1);
        X_sig=zeros(2,length(outSig));
        for k=1:length(outSig)
           X_sig(1,k)= real(outSig(k));
           X_sig(2,k)= imag(outSig(k));
        end
        Train_x_sig(:,:,:,i+addIndex)=X_sig;
        Train_y_sig(i+addIndex) =categorical(j+5);
    end
end
Train_y_sig=categorical(Train_y_sig);
save ('CNN_Training_data'+string(int2str(eee)), 'Train_x_sig','Train_y_sig');
end
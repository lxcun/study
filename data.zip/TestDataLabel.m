clc
clear all;
load('CNN_Testing_noise7_7_5_data.mat');
label=zeros(1000,1);
Trainlabels=zeros(1000,7);
for i=1:1000
    c=Train_x_sig(:,:,:,i);
    d=[c(1,:) c(2,:)];
    trainData(i,:)=d(:);
    label(i)=Train_y_sig(i);
end
for i=1:1000
    a(i,:)="|labels";
    b(i,:)="|features";
    if label(i)==1
        Trainlabels(i,:)=[1 0 0 0 0 0 0];
    end
    if label(i)==2
        Trainlabels(i,:)=[0 1 0 0 0 0 0];
    end
    if label(i)==3      
        Trainlabels(i,:)=[0 0 1 0 0 0 0];
    end
    if label(i)==4  
        Trainlabels(i,:)=[0 0 0 1 0 0 0];
    end
    if label(i)==5   
        Trainlabels(i,:)=[0 0 0 0 1 0 0];
    end
    if label(i)==6
        Trainlabels(i,:)=[0 0 0 0 0 1 0];
    end
    if label(i)==7
        Trainlabels(i,:)=[0 0 0 0 0 0 1];
    end
   x=Train_x_sig(:,:,:,i);
   x1=x(1,:);
   x2=x(2,:);
   l=a(i,:);
   f=b(i,:);
   t=Trainlabels(i,:);
    z(i,:)=[l t f x1 x2];
end
[m,n]=size(z);
fid=fopen('TestData7_7_5_1k.txt','a+');
for i=1:1:m
    for j=1:1:n
      if(j==n)
       fprintf(fid,'%s\n',z(i,j)); 
     else
        fprintf(fid,'%s\t',z(i,j));  
      end
    end
end
fclose(fid);


clear;
load ('CNN_Train_5_data', 'Train_x_sig','Train_y_sig');
N=size(Train_x_sig,4);
for i=1:N
   SNR=5+2*random('Half Normal',0,4,1);
    Train_x_sig(:,:,:,i)=awgn(Train_x_sig(:,:,:,i),SNR,'measured');
end
save ('CNN_Training_noise7_20_5_data', 'Train_x_sig','Train_y_sig');
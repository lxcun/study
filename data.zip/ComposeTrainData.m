clear;
load('CNN_Training_5_data1', 'Train_x_sig','Train_y_sig');
Train_x_sig_all=Train_x_sig;
Train_y_sig_all=Train_y_sig;
for i=1:20
    load('CNN_Training_5_data'+string(int2str(i)), 'Train_x_sig','Train_y_sig');
    Train_x_sig_all=cat(4,Train_x_sig_all,Train_x_sig);
    Train_y_sig_all=cat(1,Train_y_sig_all,Train_y_sig);
end
r=randperm( size(Train_x_sig_all,4));
Train_x_sig=Train_x_sig_all(:,:,:,r);
Train_y_sig=Train_y_sig_all(r);
save ('CNN_Train_5_data', 'Train_x_sig','Train_y_sig');
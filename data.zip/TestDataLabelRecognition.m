clc
clear all;
load('CNN_Testing_noise7_7_5_data.mat');
for i=1:1000
    c=Train_x_sig(:,:,:,i);
    d=[c(1,:) c(2,:)];
    trainData(i,:)=d(:);
    label(i)=Train_y_sig(i);
end
for i=1:1000
    b(i,:)="|features";
   x=Train_x_sig(:,:,:,i);
   x1=x(1,:);
   x2=x(2,:);
   f=b(i,:);
    z(i,:)=[f x1 x2];
end
[m,n]=size(z);
fid=fopen('TestData7_7_5r_1k.txt','a+');
for i=1:1:m
    for j=1:1:n
      if(j==n)
       fprintf(fid,'%s\n',z(i,j)); 
     else
        fprintf(fid,'%s\t',z(i,j));  
      end
    end
end
fclose(fid);


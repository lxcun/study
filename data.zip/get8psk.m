clc
clear all;
close all;
c=load('dataIQqam64.txt');
c=c'; 
c=c(1,:)+1i*c(2,:);
%fsk��Ҫ��
%  c=c/max(abs(c));
c=c*0.5/mean(abs(c));
x1=zeros(2,512);
num=length(c)/512;
label=ones(num,1)*1;
% x[i]=c(:,1+i*512:512+i*512);
for i=1:num
    x=(i-1)*512;
    k=i*512;
    z=c(x+1:k);
%   x1(:,:)=c(1:2,1+i*512:512+i*512);
    a="|labels";
    b="|features";
    if label(i)==1
        Trainlabels(i,:)=[1 0 0 0 0 0 0 0];
    end
    if label(i)==2
        Trainlabels(i,:)=[0 1 0 0 0 0 0 0];
    end
    if label(i)==3      
        Trainlabels(i,:)=[0 0 1 0 0 0 0 0];
    end
    if label(i)==4  
        Trainlabels(i,:)=[0 0 0 1 0 0 0 0];
    end
    if label(i)==5   
        Trainlabels(i,:)=[0 0 0 0 1 0 0 0];
    end
    if label(i)==6
        Trainlabels(i,:)=[0 0 0 0 0 1 0 0];
    end
    if label(i)==7
        Trainlabels(i,:)=[0 0 0 0 0 0 1 0];
    end
    if label(i)==8
        Trainlabels(i,:)=[0 0 0 0 0 0 0 1];
    end
  x11=real(z);
  x12=imag(z);
%   x11=x1(1,:);
%   x12=x1(2,:);
  t=Trainlabels(i,:);
  z1(i,:)=[a t b x11 x12];
end
  [m,n]=size(z1);
fid=fopen('TestData8psk.txt','a+');
for i=1:1:m
    for j=1:1:n
      if(j==n)
       fprintf(fid,'%s\n',z1(i,j)); 
     else
        fprintf(fid,'%s\t',z1(i,j));  
      end
    end
end
fclose(fid);
